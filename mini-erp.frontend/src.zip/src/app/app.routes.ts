import { Routes } from '@angular/router';
import { AdminLayout } from './core/layout/admin-layout/admin-layout';
import { LoginPage } from './features/auth/pages/login/login';
import { DashboardPage } from './features/dashboard/pages/dashboard/dashboard';
import { ProductListPage } from './features/products/pages/product-list/product-list';
import { CategoryListPage } from './features/categories/pages/category-list/category-list';
import { CategoryCreatePage } from './features/categories/pages/category-create/category-create';
import { CategoryEditPage } from './features/categories/pages/category-edit/category-edit';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginPage
  },
  {
  path: 'dashboard',
  canActivate: [authGuard],
  loadComponent: () =>
    import('./features/dashboard/pages/dashboard/dashboard').then(m => m.DashboardPage)
},
  {
  path: 'products',
  canActivate: [authGuard],
  children: [
    {
      path: '',
      loadComponent: () =>
        import('./features/products/pages/product-list/product-list').then(m => m.ProductListPage)
    },
    {
      path: 'new',
      loadComponent: () =>
        import('./features/products/pages/product-create/product-create').then(m => m.ProductCreatePage)
    },
    {
      path: 'edit/:id',
      loadComponent: () =>
        import('./features/products/pages/product-edit/product-edit').then(m => m.ProductEditPage)
    }
  ]
},
  {
    path: '',
    component: AdminLayout,
    canActivate: [authGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardPage
      },
      {
        path: 'products',
        component: ProductListPage
      },
      {
        path: 'categories',
        component: CategoryListPage
      },
      {
        path: 'categories/new',
        component: CategoryCreatePage
      },
      {
        path: 'categories/edit/:id',
        component: CategoryEditPage
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
        
      }
      
    ]
    
  },
  {
    path: '**',
    redirectTo: ''
  }
];